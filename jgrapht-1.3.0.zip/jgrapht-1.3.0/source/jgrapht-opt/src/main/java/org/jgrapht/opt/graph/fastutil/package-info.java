/**
 * Specialized graph implementations using the FastUtil library 
 */
package org.jgrapht.opt.graph.fastutil;
